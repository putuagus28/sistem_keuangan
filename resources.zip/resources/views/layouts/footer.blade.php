<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} UKM INSTIKI.</strong>
    All rights reserved.
</footer>
